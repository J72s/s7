const prefix = global.config.prefix;
const strings = require('../strings.json');
const utils = require('../utils');

module.exports = (client, message) => {
    if (message.content.indexOf(prefix) == 0) {
        if (message.author.id == client.user.id) return;
        
        const args = message.content.slice(prefix.length).trim().split(/ +/g);
        const command = args.shift().toLowerCase();
        const cmd = client.commands.get(command);
        
        if (!cmd) return;

        if (!global.config.allowed.includes(message.author.id) && global.config.allowed.length > 0) {
            message.channel.send(strings.permissionDenied); 
            utils.log(`${message.author.username} tried to run the command '${message.content}' but permission was not accepted`); 
            return;
        }
        
        try {
            cmd.run(client, message, args);
        } catch (error) {
            // Log the error
            console.error(error);

            // Send the error to a specified text channel
            const errorChannelId = '1240780333826445372'; // Replace 'your_text_channel_id' with the actual ID of your text channel
            const errorChannel = client.channels.cache.get(errorChannelId);
            if (errorChannel) {
                errorChannel.send(`An error occurred while executing a command:\n\`\`\`${error}\`\`\``);
            } else {
                console.error("Error channel not found.");
            }
        }

        return;
    }
};
