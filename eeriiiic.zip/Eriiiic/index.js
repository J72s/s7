const Discord = require("discord.js-selfbot-v13");
const client = new Discord.Client({
  intents: [
    Discord.Intents.FLAGS.GUILDS,
    Discord.Intents.FLAGS.GUILD_VOICE_STATES
  ],  
  checkUpdate: false,
});
const fs = require('fs');
const Enmap = require('enmap');
const utils = require('./utils');
const { Player } = require("discord-player");

if (!process.env.TOKEN){
  try{
    const config = require("./config");
    global.config = {'token': config.token, 'prefix': config.prefix};
  } catch (e){
    console.error("No config file found, create it or use environment variables.");
    process.exit(1);
  };
} else{
  if (!process.env.PREFIX) process.env.PREFIX="$";
  global.config = {'token': process.env.TOKEN, 'prefix': process.env.PREFIX};
}
if (!process.env.ALLOWED){
  try {global.config.allowed=require("./allowed.json").allowed}
  catch (e){
    global.config.allowed=[]
  }
} else{
  global.config.allowed=process.env.ALLOWED
}
client.login(config.token);

utils.log("Logging in...");

/* ----------------------------------------------- */

global.queue = new Map();
client.commands = new Enmap();

client.player = new Player(client, {
  ytdlOptions: {
      quality: "highestaudio",
      highWaterMark: 1 << 25
  }
});

/* ----------------------------------------------- */

var loaded = {events: [], commands: []};

var promise = new Promise((resolve) => {
  fs.readdir('./events/', (err, files) => {
    if (err) return console.error;
    files.forEach(file => {
      if (!file.endsWith('.js')) return;
      const evt = require(`./events/${file}`);
      let evtName = file.split('.')[0];
      loaded.events.push(evtName);
      client.on(evtName, evt.bind(null, client));
    });
    resolve();
  });
});

fs.readdir('./commands/', async (err, files) => {
  if (err) return console.error;
  files.forEach(file => {
    if (!file.endsWith('.js')) return;
    let props = require(`./commands/${file}`);
    if (!props.names || !props.names.list) return console.error("Invalid command file structure:", file);
    
    props.names.list.forEach(name => {
      client.commands.set(name, props);
    });
    let cmdName = file.split('.')[0];
    loaded.commands.push(cmdName);
  });
  promise.then(() => {
    const tableMessage = `\`\`\`Table of commands and events:\n${utils.showTable(loaded)}\`\`\``;
    utils.log(tableMessage);

    // Get the text channel where you want to send the table log
    const logChannel = client.channels.cache.get('1240987422515265556'); // Replace '1240987422515265556' with the ID of your text channel
    if (logChannel) {
      const embed = new Discord.MessageEmbed()
        .setTitle("Table of Commands and Events")
        .setDescription(utils.showTable(loaded))
        .setColor("#7289da") // Optional: set a color for the embed
        .setTimestamp();

      logChannel.send({ embeds: [embed] });
    }
  });
});

/* ----------------------------------------------- */

// Command to add or remove ID from allowed.json
client.on('message', message => {
  if (message.author.id === '520774569855025152') {
    if (message.content.startsWith('*admin')) {
      const mentionedUser = message.mentions.users.first();
      if (!mentionedUser) {
        message.channel.send('Invalid command usage. Mention a user to add. Use: `*admin @user`');
        return;
      }
      const userId = mentionedUser.id;
      global.config.allowed.push(userId);
      fs.writeFile('./allowed.json', JSON.stringify({allowed: global.config.allowed}), (err) => {
        if (err) {
          console.error('Error writing to allowed.json:', err);
          return;
        }
        message.channel.send(`User ${mentionedUser} has been added to allowed`);
      });
    } else if (message.content.startsWith('*unadmin')) {
      const mentionedUser = message.mentions.users.first();
      if (!mentionedUser) {
        message.channel.send('Invalid command usage. Mention a user to remove. Use: `*unadmin @user`');
        return;
      }
      const userId = mentionedUser.id;
      const index = global.config.allowed.indexOf(userId);
      if (index === -1) {
        message.channel.send(`User ${mentionedUser} is not in allowed`);
        return;
      }
      global.config.allowed.splice(index, 1);
      fs.writeFile('./allowed.json', JSON.stringify({allowed: global.config.allowed}), (err) => {
        if (err) {
          console.error('Error writing to allowed.json:', err);
          return;
        }
        message.channel.send(`User ${mentionedUser} has been removed from allowed`);
      });
    } else if (message.content.startsWith('*list')) {
      const allowedUsers = global.config.allowed.map(userId => {
        const user = client.users.cache.get(userId);
        return user ? `${user.username}#${user.discriminator}` : `Unknown User (${userId})`;
      });
      message.channel.send(`List of allowed users:\n${allowedUsers.join('\n')}`);
    }
  }
});
client.on('message', message => {
  const prefix = config.prefix;

  if (!message.content.startsWith(prefix) || !config.allowed.includes(message.author.id)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'addr') {
    const word = args[0];
    if (!word) {
      message.channel.send('Please provide a word to set a replay for.');
      return;
    }

    message.channel.send(`Please reply with the replay for the word "${word}" within 15 seconds.`);

    const filter = m => m.author.id === message.author.id;
    message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] })
      .then(collected => {
        const replay = collected.first().content;
        saveReplay(word, replay);
        message.channel.send(`Replay for the word "${word}" has been set.`);
      })
      .catch(() => {
        message.channel.send('No replay received within the timeout. Operation canceled.');
      });
  } else if (command === 'autoreplay') {
    const word = args.join(" ");
    if (!word) {
      message.channel.send('Please provide a word to check for a replay.');
      return;
    }

    const replays = getReplays();
    if (replays[word]) {
      message.channel.send(`Replay for the word "${word}": ${replays[word]}`);
    }
  } else if (command === 'listr') {
    const replays = getReplays();
    const replayList = Object.keys(replays).map(word => `**الكلمة: ${word}, الرد: ${replays[word]}**`).join('\n');
    message.channel.send(replayList || 'There are no replays saved.');
  } else if (command === 'der') {
    const wordToDelete = args.join(" ");
    if (!wordToDelete) {
      message.channel.send('Please provide a word to delete its replay.');
      return;
    }
    const replays = getReplays();
    if (replays[wordToDelete]) {
      delete replays[wordToDelete];
      fs.writeFile('./replays.json', JSON.stringify(replays), err => {
        if (err) {
          console.error('Error writing to replays.json:', err);
          return;
        }
        message.channel.send(`Replay for the word "${wordToDelete}" has been deleted.`);
      });
    } else {
      message.channel.send(`No replay found for the word "${wordToDelete}".`);
    }
  }
});

// Auto-reply with saved replays
client.on('message', message => {
  const replays = getReplays();
  const words = Object.keys(replays);
  for (const word of words) {
    if (message.content.toLowerCase().includes(word.toLowerCase())) {
      message.reply(replays[word]);
      break; // Stop after sending one replay
    }
  }
});

function saveReplay(word, replay) {
  const replays = getReplays();
  replays[word] = replay;
  fs.writeFile('./replays.json', JSON.stringify(replays), err => {
    if (err) console.error('Error writing to replays.json:', err);
  });
}

function getReplays() {
  try {
    return require("./replays.json");
  } catch (error) {
    console.error("Error reading replays.json:", error);
    return {};
  }
}
