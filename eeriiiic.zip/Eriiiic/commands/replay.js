const fs = require("fs");
const path = require("path");

const repliesFilePath = path.join(__dirname, "../replies.json");

module.exports.run = async (client, message, args) => {
    try {
        if (args.length < 2) {
            return message.channel.send("Usage: !addreplay <word> <reply>");
        }

        const word = args[0];
        const reply = args.slice(1).join(" ");

        message.channel.send(`Please provide the reply to "${word}" within 15 seconds.`);

        const filter = (msg) => msg.author.id === message.author.id;
        const collected = await message.channel.awaitMessages(filter, { max: 1, time: 15000, errors: ['time'] });

        const newReply = collected.first().content;

        const replies = loadReplies();
        replies[word] = newReply;
        saveReplies(replies);

        message.channel.send(`Reply for "${word}" has been updated.`);
    } catch (error) {
        console.error("Error occurred while adding autoreply:", error);
        message.channel.send("An error occurred while adding autoreply.");
    }
};

module.exports.names = {
    list: ["addreplay"]
};

function loadReplies() {
    try {
        if (fs.existsSync(repliesFilePath)) {
            const data = fs.readFileSync(repliesFilePath);
            return JSON.parse(data);
        } else {
            return {};
        }
    } catch (error) {
        console.error("Error loading autoreplies:", error);
        return {};
    }
}

function saveReplies(replies) {
    try {
        fs.writeFileSync(repliesFilePath, JSON.stringify(replies, null, 4));
    } catch (error) {
        console.error("Error saving autoreplies:", error);
    }
}
