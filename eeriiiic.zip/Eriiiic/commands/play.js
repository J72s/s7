const ytdl = require("ytdl-core");
const fetch = require("node-fetch"); // Import node-fetch for making HTTP requests
const soundcloud = require("soundcloud-downloader");
const SpotifyWebApi = require('spotify-web-api-node');

const strings = require("../strings.json");
const utils = require("../utils");

// Initialize Spotify API client
const spotifyApi = new SpotifyWebApi({
  clientId: 'b2c9a53c30e443cca17ed0103fc59046',
  clientSecret: '1086f133de9049478ba314c0793593ee'
});

module.exports.run = async (client, message, args) => {
    try {
        if (!args[0]) return message.channel.send(strings.noArgsSongSearch);

        client.channels.cache.get('1240050863007862815').send("Looking for music details...");

        let FUrl;

        if (utils.isURL(args[0])) {
            FUrl = args[0];
        } else {
            FUrl = await utils.getUrl(args);
        }

        let voiceChannel = message.member.voice.channel;
        const serverQueue = queue.get("queue");

        let songInfo;
if (FUrl.includes("soundcloud.com")) {
    const trackId = FUrl.split("/").pop(); // Extract the track ID from the SoundCloud URL
    const response = await fetch(`https://api.soundcloud.com/tracks/${trackId}?client_id=aa0dd32bfea9b0c5ef4f02aacd080604`);
    const trackData = await response.json();

    // Check if user information exists in the response
    const artist = trackData.user ? trackData.user.username : "Unknown Artist";

    // Extract relevant information
    songInfo = {
        title: trackData.title,
        duration: trackData.duration / 1000, // duration in seconds
        url: FUrl,
        artist: artist,
    };
} else if (FUrl.includes("spotify.com")) {
    const trackId = FUrl.split("/").pop();
    const spotifyTrack = await spotifyApi.getTrack(trackId);

    songInfo = {
        title: spotifyTrack.body.name,
        duration: spotifyTrack.body.duration_ms / 1000, // duration in seconds
        url: FUrl,
        artist: spotifyTrack.body.artists.map(artist => artist.name).join(", "),
    };
} else {
    songInfo = await ytdl.getBasicInfo(FUrl);
}


        const song = {
            title: songInfo.title,
            duration: songInfo.duration,
            url: FUrl,
            requestedby: message.author.username
        };

        client.channels.cache.get('1240050863007862815').send("Got music details, preparing the music to be played...");

        // Rest of your code remains the same
    } catch (error) {
        console.error('An error occurred:', error);
        // Send error message to a text channel
        message.channel.send('An error occurred while processing your request. Please try again later.');
    }
};

module.exports.names = {
    list: ["play", "p","ش","شغل"]
};
